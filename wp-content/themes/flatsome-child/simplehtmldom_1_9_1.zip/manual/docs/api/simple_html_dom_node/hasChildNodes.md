# hasChildNodes

```php
hasChildNodes ( ) : bool
```

This is a wrapper function for [`has_child`](../has_child/).